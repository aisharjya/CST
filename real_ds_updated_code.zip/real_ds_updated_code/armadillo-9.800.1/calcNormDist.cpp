#include <armadillo>
#include <omp.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>
#include <map>

using namespace std;
using namespace arma;

int sigma;
int nRows;
int nCols;
arma::mat inputData;
arma::rowvec classLabel;
double eigenDist = 0.0;
double aConst = 0.0001;
vector<vector<double> > eigenVectors;
//vector<double> eigenDistances;
vector<vector<double> > transformedData;
map<double, int> distanceMap;

arma::mat readCSV(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    arma::mat data_mat = arma::zeros<arma::mat>(datas.size(), datas[0].size());
    for (int i=0; i<datas.size(); i++) {
        arma::mat r(datas[i]);
        data_mat.row(i) = r.t();
    }
    return data_mat;
}

void readLabel(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    classLabel = arma::zeros<arma::rowvec>(datas[0].size());
    classLabel = datas[datas.size()-1];
}

void readEigenVectors(string fileName){
	fstream fin(fileName);
	string line;
	while(getline(fin, line)) {
		string str = line;
		stringstream aLine(str);
		istream_iterator<string> it(aLine);
		istream_iterator<string> end;
		vector<string> strResults(it, end);
		vector<double> rowData;
	        for(auto const& value: strResults) {
		    rowData.push_back(stod(value.c_str(), NULL));
	        }
		eigenVectors.push_back(rowData);
	} //end while
	fin.close();
}

double calculateEigenDistance(int i, int j){
	double dist = 0.0;
	for(int col=0; col<transformedData[0].size(); col++){
		dist = dist + pow((transformedData[i][col]-transformedData[j][col]),2);
	}
	return sqrt(dist);
}

void transform_1D(int e){
	//cout << "Inside transform: " << inputData.size() << endl;
	for(int i=0; i<inputData.n_rows; i++){
		double transVal = 0.0;
		vector<double> data;
		for(int j=0; j<inputData.n_cols; j++){
			transVal = transVal + (inputData.at(i,j)*eigenVectors[j][e]);
		}
		data.push_back(transVal);
		transformedData.push_back(data);
	}

	//calculate eigen distance
	eigenDist = 0.0;
	for(int i=0; i<transformedData.size(); i++){
		for(int j=(i+1); j<transformedData.size(); j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
			if(sigma == 1)
				eigenDist = eigenDist + calculateEigenDistance(i,j);
			else
				eigenDist = eigenDist - calculateEigenDistance(i,j);
		}
	}
	//eigenDistances.push_back(eigenDist);
	if(distanceMap.count(eigenDist) > 0)
		distanceMap.insert(pair<double, int>(eigenDist+aConst, e));
	else
		distanceMap.insert(pair<double, int>(eigenDist, e));

	transformedData.clear();
	vector<vector<double> >().swap(transformedData);
}

void transform_kD(int dims){
	for(int i=0; i<inputData.n_rows; i++){
		vector<double> data;
		for(int k=0; k<dims; k++){
			double transVal = 0.0;
			map<double, int>::iterator itAtOffset = distanceMap.begin();
			advance(itAtOffset, k);
			//cout << "itAtOffset->second: " << itAtOffset->second << " " << i << endl;
			for(int j=0; j<inputData.n_cols; j++){
				transVal = transVal + (inputData.at(i,j) * eigenVectors[j][itAtOffset->second]);
			}
			data.push_back(transVal);
		}
		transformedData.push_back(data);
	}
}

double ft_normalized_dist(){
	double num = 0.0;
	double denom = 0.0;
	int same = 0; 
	int diff = 0;
	for(int i=0; i<transformedData.size(); i++){
		for(int j=(i+1); j<transformedData.size(); j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
			if(sigma == 1){
				num = num + calculateEigenDistance(i,j);
				same++;
			}else{
				denom = denom + calculateEigenDistance(i,j);
				diff++;
			}
		}
	}
	return ((num/same)/(denom/diff));
}

void ft_classOrder(){
	vector<int> g_cumulative(transformedData.size());
	for(int i=0; i<inputData.size(); i++){
//	for(int i=0; i<3; i++){
		map<double, int> distVec;
		vector<int> cumulative(transformedData.size());
		for(int j=0; j<transformedData.size(); j++){
			distVec.insert(pair<double, int>(calculateEigenDistance(i,j), (classLabel[i] == classLabel[j] ? 1 : 0)));
		}
		map<double, int>::iterator it;
		int k = 0;
		for ( it = distVec.begin(); it != distVec.end(); it++ ){
			if(k != 0)
	    			cumulative[k] = it->second + cumulative[k - 1];
			else	
				cumulative[k] = it->second;
			//cout << cumulative[k] << " ";
			g_cumulative[k] += cumulative[k];
			k++;		
		}
		//cout << endl;		
	}
	for(int l = 0; l < g_cumulative.size(); l++)
		cout << (double)g_cumulative[l]/transformedData.size() << endl;
}

double calculateDistance(int i, int j){
	double dist = 0.0;
	for(int col=0; col<inputData.n_cols; col++){
		dist = dist + pow((inputData.at(i,col)-inputData.at(j,col)),2);
	}
	return sqrt(dist);
}

void classOrder(){
	vector<int> g_cumulative(inputData.n_rows);
	for(int i=0; i<inputData.n_rows; i++){
		map<double, int> distVec;
		vector<int> cumulative(inputData.n_rows);
		for(int j=0; j<inputData.n_rows; j++){
			distVec.insert(pair<double, int>(calculateDistance(i,j), (classLabel[i] == classLabel[j] ? 1 : 0)));
		}
		map<double, int>::iterator it;
		int k = 0;
		for ( it = distVec.begin(); it != distVec.end(); it++ ){
			if(k != 0)
	    			cumulative[k] = it->second + cumulative[k - 1];
			else	
				cumulative[k] = it->second;
			//cout << cumulative[k] << " ";
			g_cumulative[k] += cumulative[k];
			k++;		
		}
		//cout << endl;		
	}
	for(int l = 0; l < g_cumulative.size(); l++)
		cout << (double)g_cumulative[l]/inputData.n_rows << endl;
}

double normalized_dist(){
	double num = 0.0;
	double denom = 0.0;
	int same = 0; 
	int diff = 0;
	for(int i=0; i<inputData.n_rows; i++){
		for(int j=(i+1); j<inputData.n_rows; j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : 0);
			if(sigma == 1){
				num = num + calculateDistance(i,j);
				same++;
			}else{
				denom = denom + calculateDistance(i,j);
				diff++;
			}
		}
	}
	return ((num/same)/(denom/diff));
}

double abs_dist(){
	double num = 0.0;
	double denom = 0.0;
	int same = 0; 
	int diff = 0;
	for(int i=0; i<inputData.n_rows; i++){
		for(int j=(i+1); j<inputData.n_rows; j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : 0);
			if(sigma == 1){
				num = num + calculateDistance(i,j);
				same++;
			}else{
				denom = denom + calculateDistance(i,j);
				diff++;
			}
		}
	}
	return abs(num - denom);
}

bool hasSuffix(string const &fullString, string const &ending) {
    if (fullString.length() >= ending.length()) {
        return (0 == fullString.compare (fullString.length() - ending.length(), ending.length(), ending));
    } else {
        return false;
    }
}

int main(int argc, char *argv[]) {
	string inputFilePath = argv[1];
	string originalDataFolder = argv[2];
	string eigenVectorFolder = argv[3];
	string transformedDataFolder = argv[4];
	int noOfdims = atoi(argv[5]);	
	inputData = readCSV(inputFilePath);
	nRows = inputData.n_rows;
	nCols = inputData.n_cols;
	//For Feature Transformation Method
	if(eigenVectorFolder.size() > 0 or !eigenVectorFolder.empty()){
		string classLabelPath = originalDataFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_class";
		string outputPath = transformedDataFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1);
		readLabel(classLabelPath);
		if(hasSuffix(inputFilePath.substr(inputFilePath.find_last_of("/\\")+1), "_test")){
			string subStr1 = inputFilePath.substr(inputFilePath.find_last_of("/\\")+1);
			string newfilename = subStr1.substr(0,subStr1.find_last_of('_'))+"_train";
			cout << "subStr1: " << subStr1 << " newfilename: " << newfilename << endl;
			readEigenVectors(eigenVectorFolder + newfilename + "_vectors");
		}else
			readEigenVectors(eigenVectorFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_vectors");
			
		for(int i=0; i<eigenVectors[0].size(); i++)
			transform_1D(i);
		transform_kD(noOfdims);
		//ft_classOrder(); //for testing
		//exit(0); //forced exit temporary for testing
		cout << ft_normalized_dist() << ' ' << endl;
		freopen(outputPath.c_str(), "w", stdout);
		for(int i=0; i<transformedData.size(); i++){
			for(int j=0; j<transformedData[0].size(); j++){
				cout << transformedData[i][j];
				if(j != (transformedData[0].size() - 1)) cout << ' ';
			}
			cout << endl;
		}
		fclose(stdout);
	}else {
		//For other FS/FE Methods
		string f2;
		string f1 = inputFilePath.substr(inputFilePath.find_last_of("/\\")+1);
		if((inputFilePath.substr(0,inputFilePath.find_first_of("/\\")+1)).compare(originalDataFolder) != 0) /* To extract class label filename for files '<FS_>*' [Eg. PCA_*, SelectKBest_*] */
			f2 = f1.substr(f1.find_first_of("_")+1);
		else
			f2 = f1;
		//cout << "f2: " << f2 << endl;	
		string classLabelPath = originalDataFolder + f2 + "_class";
		readLabel(classLabelPath);
		//classOrder(); //for testing
		//exit(0); //forced exit temporary for testing
		//cout << normalized_dist() << ' ' << endl;
		cout << abs_dist() << ' ' << endl;
	}
	return 0;
}

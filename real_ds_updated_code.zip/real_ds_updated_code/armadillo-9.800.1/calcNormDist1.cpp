#include <armadillo>
#include <omp.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>
#include <map>

using namespace std;
using namespace arma;

int sigma;
int nRows;
int nCols;
arma::mat inputData;
arma::rowvec classLabel;

arma::mat readCSV(const string &filename, const string &delimeter = " ") {
    //cout << "Inside readCSV(): " << filename << endl;
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    arma::mat data_mat = arma::zeros<arma::mat>(datas.size(), datas[0].size());
    for (int i=0; i<datas.size(); i++) {
        arma::mat r(datas[i]);
        data_mat.row(i) = r.t();
    }
    /*classLabel = arma::zeros<arma::rowvec>(data_mat.n_rows);
    classLabel = datas[datas.size()-1];*/
    return data_mat;
}

void readLabel(const string &filename, const string &delimeter = " ") {
    //cout << "Inside readLabel()" << endl;
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    classLabel = arma::zeros<arma::rowvec>(datas[0].size());
    classLabel = datas[datas.size()-1];
}

double calculateDistance(int i, int j){
	double dist = 0.0;
	for(int col=0; col<inputData.n_cols; col++){
		dist = dist + pow((inputData.at(i,col)-inputData.at(j,col)),2);
	}
	return sqrt(dist);
}

double normalized_dist(){
	double num = 0.0;
	double denom = 0.0;
	int same = 0; 
	int diff = 0;
	for(int i=0; i<inputData.n_rows; i++){
		for(int j=(i+1); j<inputData.n_rows; j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : 0);
			if(sigma == 1){
				num = num + calculateDistance(i,j);
				same++;
			}else{
				denom = denom + calculateDistance(i,j);
				diff++;
			}
		}
	}
	//cout << num << " " << denom << " " << same << " " << diff << " " << num/same << " " << denom/diff << endl;
	return ((num/same)/(denom/diff));
}

int main(int argc, char *argv[]) {
	ifstream infile("Synthetic_Dataset1/synDataList");
	string line;
	while(getline(infile, line)){
		readLabel("Synthetic_Dataset1/3d_"+line +"_class");
		inputData = readCSV("Synthetic_Dataset1/SelectKBest_3_"+line);
		nRows = inputData.n_rows;
		nCols = inputData.n_cols;
		/*cout << nRows << " " << nCols << endl;
		cout << inputData.at(0,0) << endl;
		cout << classLabel.n_rows << " " << classLabel.n_cols << " " << classLabel.at(0,10) << endl;*/
		cout << normalized_dist() << endl;
		//inputData.clear();
	}
	return 0;
}

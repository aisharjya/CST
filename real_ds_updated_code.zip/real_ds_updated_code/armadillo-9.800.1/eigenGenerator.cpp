#include <armadillo>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>

using namespace std;
using namespace arma;

int nRows;
int nCols;
mat inputMatrix;

mat readCSV(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    arma::mat data_mat = arma::zeros<arma::mat>(datas.size(), datas[0].size());
    for (int i=0; i<datas.size(); i++) {
        mat r(datas[i]);
        data_mat.row(i) = r.t();
    }
    return data_mat;
}

int main(int argc, const char **argv) {
	/* Read input data */
	//inputMatrix = readCSV("../Real_Datasets/reducedMat");
	//inputMatrix = readCSV("data_100_2_0.2,0.2_10/reducedMat_1");
	string inputFilePath = argv[1];
	string outputFolder = argv[2];
	string outputEigenVecFilePath = outputFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_vectors";
	string outputEigenValFilePath = outputFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_values";
	inputMatrix = readCSV(inputFilePath);
	inputMatrix.raw_print();
	nRows = inputMatrix.n_rows;
	nCols = inputMatrix.n_cols;
	cout << nRows << " " << nCols << endl;
	cout << inputMatrix.at(0,1) << endl;
	
	vec eigval;
	mat eigvec;
	/*cx_vec eigval;
	cx_mat eigvec;*/
	eig_sym(eigval, eigvec, inputMatrix);
	/*eig_gen(eigval, eigvec, inputMatrix);*/
	freopen(outputEigenVecFilePath.c_str(), "w", stdout);
	eigvec.raw_print();
	freopen(outputEigenValFilePath.c_str(), "w", stdout);
	eigval.raw_print();
	return 0;
}

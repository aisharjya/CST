#include <armadillo>
#include <omp.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>
#include <map>

using namespace std;
using namespace arma;

int sigma;
int nRows;
int nCols;
arma::mat inputData;
arma::rowvec classLabel;
double eigenDist = 0.0;
double aConst = 0.0001;
vector<vector<double> > eigenVectors;
//vector<double> eigenDistances;
vector<vector<double> > transformedData;
map<double, int> distanceMap;

arma::mat readCSV(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    arma::mat data_mat = arma::zeros<arma::mat>(datas.size(), datas[0].size());
    for (int i=0; i<datas.size(); i++) {
        arma::mat r(datas[i]);
        data_mat.row(i) = r.t();
    }
    return data_mat;
}

void readLabel(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    classLabel = arma::zeros<arma::rowvec>(datas[0].size());
    classLabel = datas[datas.size()-1];
}

void readPerturbedVectors(string fileName){
	fstream fin(fileName);
	string line;
	while(getline(fin, line)) {
		string str = line;
		stringstream aLine(str);
		istream_iterator<string> it(aLine);
		istream_iterator<string> end;
		vector<string> strResults(it, end);
		vector<double> rowData;
	        for(auto const& value: strResults) {
		    rowData.push_back(stod(value.c_str(), NULL));
	        }
		eigenVectors.push_back(rowData);
	} //end while
	fin.close();
	for(int i = 0; i < eigenVectors.size(); i++){
		for(int j = 0; j < eigenVectors[0].size(); j++){
			cout << eigenVectors[i][j] << ' ';
		}
		cout << endl;
	}
}

double calculateEigenDistance(int i, int j){
	double dist = 0.0;
	for(int col=0; col<transformedData[0].size(); col++){
		dist = dist + pow((transformedData[i][col]-transformedData[j][col]),2);
	}
	return sqrt(dist);
}

double ft_normalized_dist(){
	double num = 0.0;
	double denom = 0.0;
	int same = 0; 
	int diff = 0;
	for(int i=0; i<transformedData.size(); i++){
		for(int j=(i+1); j<transformedData.size(); j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
			if(sigma == 1){
				num = num + calculateEigenDistance(i,j);
				same++;
			}else{
				denom = denom + calculateEigenDistance(i,j);
				diff++;
			}
		}
	}
	return ((num/same)/(denom/diff));
}

void transform_1D(int e){
	transformedData.clear();
	vector<vector<double> >().swap(transformedData);
	for(int i=0; i<inputData.n_rows; i++){
		double transVal = 0.0;
		vector<double> data;
		for(int j=0; j<inputData.n_cols; j++){
			transVal = transVal + (inputData.at(i,j)*eigenVectors[j][e]);
		}
		data.push_back(transVal);
		transformedData.push_back(data);
	}

	//calculate eigen distance
	eigenDist = 0.0;
	for(int i=0; i<transformedData.size(); i++){
		for(int j=(i+1); j<transformedData.size(); j++){
			sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
			if(sigma == 1)
				eigenDist = eigenDist + calculateEigenDistance(i,j);
			else
				eigenDist = eigenDist - calculateEigenDistance(i,j);
		}
	}
	cout << eigenDist << " " << ft_normalized_dist() << endl;
	transformedData.clear();
	vector<vector<double> >().swap(transformedData);
}

int main(int argc, char *argv[]) {
	string inputFilePath = argv[1];		//Read the train dataset
	string originalDataFolder = argv[2];	//Read the class labels of train dataset
	string perturbedVectorFile = argv[3];	//Read the perturbed eigen vectors
	inputData = readCSV(inputFilePath);
	nRows = inputData.n_rows;
	nCols = inputData.n_cols;
	string classLabelPath = originalDataFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_class";
	readLabel(classLabelPath);
	readPerturbedVectors(perturbedVectorFile);
	for(int i=0; i<eigenVectors[0].size(); i++)
		transform_1D(i);
}

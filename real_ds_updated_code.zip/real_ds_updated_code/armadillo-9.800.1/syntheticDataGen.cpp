#include <armadillo>
#include <omp.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>
//#include <bits/stdc++.h>

using namespace std;
using namespace arma;

int nRows;
int nCols;
int nFeatureDims;
int totalDims;
arma::mat binaryMatrix;
arma::mat A;
arma::colvec B;
arma::colvec X;
vector<int> shuffleIndexArray;
arma::mat highDimMatrix;

int randomfunc(int j) { 
    return rand() % j; 
}

void shuffle_array(int arr[], int n) {
	srand(time(0)); 
	random_shuffle(arr, arr + n);
	shuffleIndexArray.clear(); 
	for (int i = 0; i < n; ++i) 
        	//cout << arr[i] << " ";
		shuffleIndexArray.push_back(arr[i]); 
    	//cout << endl;
}

int main(int argc, const char **argv) {
	nRows = atoi(argv[1]);
	nCols = atoi(argv[2]);
	nFeatureDims = atoi(argv[3]);
	totalDims = atoi(argv[4]);
	string inputFilePath = argv[5];
	string inputFile = inputFilePath.substr(inputFilePath.find_last_of("/\\")+1);
	string outputPath = argv[6]+inputFile;
	int a[nCols];
	for(int i = 0; i < nCols; i++)
		a[i] = i;

	if((nCols <= (nRows * nFeatureDims)) && (totalDims >= nCols)){
		//Generate a binary matrix A
		mat binaryMatrix = zeros<mat>(nRows, nCols);
		for(int i = 0; i < nRows; i++){
			shuffle_array(a, nCols);
			for(int j = 0; j < nFeatureDims; j++)
//				binaryMatrix.at(i,shuffleIndexArray.at(j)) = 1;	 // set weight to 1 -- test 1
				binaryMatrix.at(i,shuffleIndexArray.at(j)) = 0.5 + (rand() / double(RAND_MAX))/2.0;	 // set weight to a random real number between 0.5 and 1 -- test 2	

			for(int j = nFeatureDims; j < nCols; j++)	
				binaryMatrix.at(i,shuffleIndexArray.at(j)) = (rand() / double(RAND_MAX))/20.0;	 // set weight to a random real number between 0 and 0.05 -- test 3		
		}
		binaryMatrix.raw_print();  // we now have created a binary matrix with nFeatureDims 1s per row


		A = pinv( binaryMatrix );  
		//A = binaryMatrix.t() * inv(binaryMatrix * binaryMatrix.t());
		A.raw_print();
		mat a;
		a.load(inputFilePath);
		for(int i = 0; i < a.n_rows; i++){
			B = a.row(i).t();
			//B.raw_print();
			X = A * B;
			//trans(X).raw_print();
			highDimMatrix.insert_rows(i, trans(X));
		}

		for(int i = 0; i < highDimMatrix.n_rows; i++){
			for(int j = 0; j < highDimMatrix.n_cols; j++){
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.05 - (rand() / double(RAND_MAX))/10.0) ; // add +/- 5% noise to each value -- test 4
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.1 - (rand() / double(RAND_MAX))/5.0) ; // add +/- 10% noise to each value -- test 5
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.15 - (rand() / double(RAND_MAX))/3.32) ; // add +/- 15% noise to each value -- test 6
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.20 - (rand() / double(RAND_MAX))/2.5) ; // add +/- 20% noise to each value -- test 7
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.25 - (rand() / double(RAND_MAX))/2) ; // add +/- 25% noise to each value -- test 8
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.30 - (rand() / double(RAND_MAX))/1.66) ; // add +/- 30% noise to each value -- test 9
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.35 - (rand() / double(RAND_MAX))/1.43) ; // add +/- 35% noise to each value -- test 10
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.40 - (rand() / double(RAND_MAX))/1.25) ; // add +/- 40% noise to each value -- test 11
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.45 - (rand() / double(RAND_MAX))/1.12) ; // add +/- 45% noise to each value -- test 12
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.50 - (rand() / double(RAND_MAX))) ; // add +/- 50% noise to each value -- test 13
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.55 - (rand() / double(RAND_MAX))/0.91) ; // add +/- 55% noise to each value -- test 14				
				highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (0.60 - (rand() / double(RAND_MAX))/0.84) ; // add +/- 60% noise to each value -- test 15
				//highDimMatrix.at(i,j) += highDimMatrix.at(i,j) * (1.00 - (rand() / double(RAND_MAX))/0.5) ; // add +/- 100% noise to each value -- test 16
			}
		}

		mat  b = randn<mat>(highDimMatrix.n_rows, totalDims - highDimMatrix.n_cols);
		auto joined_mat = arma::join_rows(highDimMatrix,b);
		cout << size(highDimMatrix) << " " << size(joined_mat) << endl;
		freopen(outputPath.c_str(), "w", stdout);
		joined_mat.raw_print();			
	}
	return 0;
}

#include <armadillo>
#include <omp.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <istream>
#include <ostream>
#include <iterator>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <functional>
#include <math.h>

using namespace std;
using namespace arma;

int sigma;
int nRows;
int nCols;
arma::mat inputData;
arma::rowvec classLabel;
arma::mat intermediateEqns;
arma::mat intermediateMat;
arma::mat equations;

arma::mat readCSV(const string &filename, const string &delimeter = " ") {
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    arma::mat data_mat = arma::zeros<arma::mat>(datas.size(), datas[0].size());
    for (int i=0; i<datas.size()-1; i++) {
        arma::mat r(datas[i]);
        data_mat.row(i) = r.t();
    }
    /*classLabel = arma::zeros<arma::rowvec>(data_mat.n_rows);
    classLabel = datas[datas.size()-1];*/
    return data_mat;
}

void readLabel(const string &filename, const string &delimeter = " ") {
    //cout << "Inside readLabel()" << endl;
    ifstream csv(filename);
    vector<vector<double> > datas;
    for(string line; getline(csv, line); ) {
        vector<double> data;
        // split string by delimeter
        auto start = 0U;
        auto end = line.find(delimeter);
        while (end != string::npos) {
            data.push_back(stod(line.substr(start, end - start)));
            start = end + delimeter.length();
            end = line.find(delimeter, start);
        }
        data.push_back(stod(line.substr(start, end)));
        datas.push_back(data);
    }
    classLabel = arma::zeros<arma::rowvec>(datas[0].size());
    classLabel = datas[datas.size()-1];
    classLabel.raw_print();
}

int main(int argc, const char **argv) {

	/* Read input data */
	//inputData = readCSV("../Real_Datasets/GSE4115_Transposed1");
	string inputFilePath = argv[1];
	string outputFolder = argv[2];
	string originalFolder = argv[3];
	string classLabelPath = originalFolder + inputFilePath.substr(inputFilePath.find_last_of("/\\")+1) + "_class";
	string outputFilePath = outputFolder+inputFilePath.substr(inputFilePath.find_last_of("/\\")+1);
	cout << "inputFilePath: " << inputFilePath << endl;
	cout << "classLabelPath: " << classLabelPath << endl;
	cout << "outputFilePath: " << outputFilePath << endl;
	inputData = readCSV(inputFilePath);
	readLabel(classLabelPath);
	nRows = inputData.n_rows;
	nCols = inputData.n_cols;
	cout << nRows << " " << nCols << endl;
	cout << inputData.at(0,0) << endl;

	intermediateEqns = zeros<mat>(nCols, nCols);
	for(int i = 0; i < inputData.n_rows; i++){
		cout << "i: " << i << endl;
		for(int j = 0; j < inputData.n_rows; j++){
			if(j < i) continue;
			intermediateMat = ones<mat>(inputData.n_cols,inputData.n_cols);
			sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
			intermediateMat.each_row() %= inputData.row(i);
			if(i == j)
				intermediateMat.each_col() %= -1*inputData.row(j).t();
			else if(sigma == 1)
				intermediateMat.each_col() %= -2*inputData.row(j).t();
			else if(sigma == -1)
				intermediateMat.each_col() %= 2*inputData.row(j).t();
			intermediateEqns += intermediateMat;
		}
	}
	equations = zeros<mat>(nCols, nCols);
	equations = intermediateEqns + intermediateEqns.t();
	//freopen("../Real_Datasets/reducedMat", "w", stdout);
	freopen(outputFilePath.c_str(), "w", stdout);
	equations.raw_print();
	/*vec eigval;
	mat eigvec;
	eig_sym(eigval, eigvec, equations);
	eigvec.raw_print();*/

	/*#pragma omp parallel shared(inputData)
	{
		intermediateEqns = zeros<mat>(nCols, nCols);		
		for(int i = 0; i < inputData.n_rows; i++){
			cout << "i: " << i << endl;
			arma::mat intermediateEqns_local = zeros<mat>(nCols, nCols);
			#pragma omp for
			for(int j = 0; j < inputData.n_rows; j++){
				if(j < i) continue;
				intermediateMat = ones<mat>(inputData.n_cols,inputData.n_cols);
				sigma = (classLabel[i] == classLabel[j] ? 1 : -1);
				intermediateMat.each_row() %= inputData.row(i);
				if(i == j)
					intermediateMat.each_col() %= -1*inputData.row(j).t();
				else if(sigma == 1)
					intermediateMat.each_col() %= -2*inputData.row(j).t();
				else if(sigma == -1)
					intermediateMat.each_col() %= 2*inputData.row(j).t();
				intermediateEqns_local += intermediateMat;
			}
			#pragma omp critical
			intermediateEqns += intermediateEqns_local;
		}
	}
	equations = zeros<mat>(nCols, nCols);
	equations = intermediateEqns + intermediateEqns.t();
	freopen("../Real_Datasets/reducedMat", "w", stdout);
	equations.raw_print();*/
	return 0;
}

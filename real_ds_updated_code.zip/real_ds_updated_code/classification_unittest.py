import pandas
import numpy
import sys
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_classif
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import balanced_accuracy_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

def main():
	url1 = str(sys.argv[1]) + "_train"
	url2 = url1 + "_class"
	url3 = str(sys.argv[1]) + "_test"
	url4 = url3 + "_class"	
	_k = int(sys.argv[2])
	#print(url1)

	df_train = pandas.read_csv(url1, header=None, sep=' ')
	df_train_class = pandas.read_csv(url2, header=None, sep=' ')
	df_train_class = numpy.ravel(df_train_class, order='C')
	df_test = pandas.read_csv(url3, header=None, sep=' ')
	df_test_class = pandas.read_csv(url4, header=None, sep=' ')
	df_test_class = numpy.ravel(df_test_class, order='C')
	#print df_test_class	

	PCA_KNN(df_train, df_test, df_train_class, df_test_class, _k)
	PCA_SVM(df_train, df_test, df_train_class, df_test_class, _k)
	PCA_GNB(df_train, df_test, df_train_class, df_test_class, _k)
	#PCA_RF(df_train, df_test, df_train_class, df_test_class, _k)
	SelectKBest_KNN(df_train, df_test, df_train_class, df_test_class, _k)
	SelectKBest_SVM(df_train, df_test, df_train_class, df_test_class, _k)
	SelectKBest_GNB(df_train, df_test, df_train_class, df_test_class, _k)
	#SelectKBest_RF(df_train, df_test, df_train_class, df_test_class, _k)

	url5 = str(sys.argv[3])
	X_t_train = pandas.read_csv(url5+'_train', header=None, sep=' ')
	X_t_test = pandas.read_csv(url5+'_test', header=None, sep=' ')

	FT_KNN(X_t_train, X_t_test, df_train_class, df_test_class, _k)
	FT_SVM(X_t_train, X_t_test, df_train_class, df_test_class, _k)
	FT_GNB(X_t_train, X_t_test, df_train_class, df_test_class, _k)
	#FT_RF(X_t_train, X_t_test, df_train_class, df_test_class, _k)

	return 0

def PCA_KNN(X_train, X_test, y_train, y_test, _k):
	pca = PCA(n_components=_k)
	pca.fit(X_train)
	X_t_train = pca.transform(X_train)
	X_t_test = pca.transform(X_test)
	neigh = KNeighborsClassifier(n_neighbors=3)
	neigh.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, neigh.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0


def PCA_SVM(X_train, X_test, y_train, y_test, _k):
	#print("PCA_SVM:"),
	pca = PCA(n_components=_k)
	pca.fit(X_train)
	X_t_train = pca.transform(X_train)
	X_t_test = pca.transform(X_test)
	clf = SVC(kernel='linear', C=1)
	clf.fit(X_t_train, y_train)
	#print clf.predict(X_t_test)
	print(balanced_accuracy_score(y_test, clf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def PCA_GNB(X_train, X_test, y_train, y_test, _k):
	#print("PCA_GNB"),
	pca = PCA(n_components=_k)
	pca.fit(X_train)
	X_t_train = pca.transform(X_train)
	X_t_test = pca.transform(X_test)
	gnb = GaussianNB()
	gnb.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, gnb.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def PCA_RF(X_train, X_test, y_train, y_test, _k):
	#print("PCA_RF"),
	pca = PCA(n_components=_k)
	pca.fit(X_train)
	X_t_train = pca.transform(X_train)
	X_t_test = pca.transform(X_test)
	rf = RandomForestClassifier(random_state=137)
	rf.fit(X_t_train, y_train)	
	print(balanced_accuracy_score(y_test, rf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def SelectKBest_SVM(X_train, X_test, y_train, y_test, _k):
	#print("SelectKBest_SVM:"),
	selectKBest = SelectKBest(score_func=mutual_info_classif, k=_k)
	selectKBest.fit(X_train, y_train)
	X_t_train = selectKBest.transform(X_train)
	X_t_test = selectKBest.transform(X_test)
	clf = SVC(kernel='linear', C=1)
	clf.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, clf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def SelectKBest_KNN(X_train, X_test, y_train, y_test, _k):
	#print("SelectKBest_SVM:"),
	selectKBest = SelectKBest(score_func=mutual_info_classif, k=_k)
	selectKBest.fit(X_train, y_train)
	X_t_train = selectKBest.transform(X_train)
	X_t_test = selectKBest.transform(X_test)
	neigh = KNeighborsClassifier(n_neighbors=3)
	neigh.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, neigh.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def SelectKBest_GNB(X_train, X_test, y_train, y_test, _k):
	#print("SelectKBest_GNB:"),
	selectKBest = SelectKBest(score_func=mutual_info_classif, k=_k)
	selectKBest.fit(X_train, y_train)
	X_t_train = selectKBest.transform(X_train)
	X_t_test = selectKBest.transform(X_test)
	gnb = GaussianNB()
	gnb.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, gnb.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def SelectKBest_RF(X_train, X_test, y_train, y_test, _k):
	#print("SelectKBest_RF:"),
	selectKBest = SelectKBest(score_func=mutual_info_classif, k=_k)
	selectKBest.fit(X_train, y_train)
	X_t_train = selectKBest.transform(X_train)
	X_t_test = selectKBest.transform(X_test)
	rf = RandomForestClassifier(random_state=137)
	rf.fit(X_t_train, y_train)	
	print(balanced_accuracy_score(y_test, rf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def FT_SVM(X_t_train, X_t_test, y_train, y_test, _k):
	#print("FT_SVM:"),
	clf = SVC(kernel='linear', C=1)
	clf.fit(X_t_train, y_train)
	#print clf.predict(X_t_test)
	print(balanced_accuracy_score(y_test, clf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, clf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def FT_KNN(X_t_train, X_t_test, y_train, y_test, _k):
	neigh = KNeighborsClassifier(n_neighbors=3)
	neigh.fit(X_t_train, y_train)
	print(balanced_accuracy_score(y_test, neigh.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, neigh.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def FT_GNB(X_t_train, X_t_test, y_train, y_test, _k):
	#print("FT_GNB:"),
	gnb = GaussianNB()
	gnb.fit(X_t_train, y_train)
	#print gnb.predict(X_t_test)
	print(balanced_accuracy_score(y_test, gnb.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, gnb.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

def FT_RF(X_t_train, X_t_test, y_train, y_test, _k):
	#print("FT_RF:"),
	rf = RandomForestClassifier(random_state=137)
	rf.fit(X_t_train, y_train)
	#print rf.predict(X_t_test)	
	print(balanced_accuracy_score(y_test, rf.predict(X_t_test)), end=" ", flush=True)
	#print(f1_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(precision_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	#print(recall_score(y_test, rf.predict(X_t_test), average='binary'), end=" ", flush=True)
	return 0

main()

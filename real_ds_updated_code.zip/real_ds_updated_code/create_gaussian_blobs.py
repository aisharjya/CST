import matplotlib.pyplot as plt;
#import seaborn as sns; sns.set();
import numpy as np;
from sklearn.datasets.samples_generator import make_blobs;
import sys;
import pandas as pd;

# Generate some data
samples = int(sys.argv[1])
n_centers = int(sys.argv[2])
std_cluster = [float(sys.argv[3]), float(sys.argv[4])]
features = int(sys.argv[5])
sampleNo = int(sys.argv[6])

folderLoc = str(sys.argv[7])
outPlotLoc = str(sys.argv[8])
labelLoc = str(sys.argv[9])

X, y_true = make_blobs(n_samples=samples, centers=n_centers,
                       cluster_std=std_cluster, n_features=features)
#X = X[:, ::-1] # flip axes for better plotting
#print('\n'.join(' '.join(str(cell) for cell in row) for row in X))
#print(y_true)
df = pd.DataFrame(data=X)
df.to_csv(folderLoc+str(sys.argv[1])+'_'+str(sys.argv[2])+'_'+str(sys.argv[3])+'_'+str(sys.argv[5])+'_'+str(sys.argv[6]), sep=' ', index=False, header=False)
with open(labelLoc+str(sys.argv[1])+'_'+str(sys.argv[2])+'_'+str(sys.argv[3])+'_'+str(sys.argv[5])+'_'+str(sys.argv[6])+'_class', "w") as myfile:
	myfile.write(" ".join(map(str, y_true.tolist())))

#labels = y_true
#plt.scatter(X[:, 0], X[:, 1], c=labels, s=40);
#plt.show();

import numpy as np
import sys

inputFilePath = sys.argv[1]
with open(inputFilePath, 'r') as f:
    m = [[float(num) for num in line.split(' ')] for line in f]

outputFolder = sys.argv[2]
outputEigenVecFilePath = outputFolder + inputFilePath[inputFilePath.rfind("/")+1:] + "_vectors"
outputEigenValFilePath = outputFolder + inputFilePath[inputFilePath.rfind("/")+1:] + "_values"

eigenvalues, eigenvectors = np.linalg.eig(m)

np.savetxt(outputEigenVecFilePath, eigenvectors)
np.savetxt(outputEigenValFilePath, eigenvalues)

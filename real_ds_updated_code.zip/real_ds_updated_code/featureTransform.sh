#! /bin/bash

generateData(){
	mkdir -p ${11}
	mkdir -p ${12}
	mkdir -p ${13}
	mkdir -p ${14}
	mkdir -p ${15}
	mkdir -p ${16}
	mkdir -p ${17}
	mkdir -p ${18}
	mkdir -p ${19}
	mkdir -p ${20}
	mkdir -p ${23}
	mkdir -p ${25}
	for (( i = 1; i <= $6; i++))
	do
		python3 create_gaussian_blobs.py $1 $2 $3 $4 $5 ${i} ${25} ${23} ${12}
		#python3 make_classification.py $1 $2 $3 $5 ${i} ${25} ${23} ${12} ${21}
		python3 random_rotation_mat.py ${25}$1_$2_$3_$5_${i} ${12} ${5}
		#D=$(./calcNormDist ${11}$1_$2_$3_$5_${i} ${11} '' '' '')
		#echo ${D}
		python3 trainTestSplit.py ${11}$1_$2_$3_$5_${i} ${17} ${24} ${22}
		for (( j = 1; j <= ${24}; j++ ))
		do
			./transform ${17}$1_$2_$3_$5_${i}_${j}'_train' ${18} ${17}
			python3 eigenGen.py ${18}$1_$2_$3_$5_${i}_${j}'_train' ${19}
			D=$(./calcNormDist ${17}$1_$2_$3_$5_${i}_${j}'_train' ${17} '' '' '')
			echo ${D}
			echo -n "`python3 solve_linear_equations.py ${17}$1_$2_$3_$5_${i}_${j} ${18}$1_$2_$3_$5_${i}_${j}'_train' ${19}$1_$2_$3_$5_${i}_${j}'_train_vectors' ${21} ${D} ${20}`"
			echo -n "`python3 classification_unittest.py ${17}$1_$2_$3_$5_${i}_${j} ${21} ${20}$1_$2_$3_$5_${i}_${j}`" >> classification_score$1_$2_$3_$5_${i}_${21}_${22}.csv
			echo '' >> classification_score$1_$2_$3_$5_${i}_${21}_${22}.csv
			if [[ ${j} -eq ${24} ]]; then
				echo -n "`awk -F'[ ]'  '{for(k=1; k<=NF; k++) {total[k] += $k;}}; END {for(k=1; k<=NF; k++) printf " %s", total[k]/NR}' classification_score$1_$2_$3_$5_${i}_${21}_${22}.csv`" >> classification_score$1_$2_$3_$5_${21}_${22}.csv
				echo '' >> classification_score$1_$2_$3_$5_${21}_${22}.csv
			fi
		done
		if [[ ${i} -eq ${6} ]]; then
				echo -n $1' '$2' '$3' '$5' '${21}' '${22}' ' >> classif_file.csv
				echo -n "`awk -F'[ ]'  '{for(i=1; i<=NF; i++) {total[i] += $i;}}; END {for(i=1; i<=NF; i++) printf "%s ", total[i]/NR}' classification_score$1_$2_$3_$5_${21}_${22}.csv`" >> classif_file.csv
				echo '' >> classif_file.csv
		fi
	done
}

generateData 200 2 20.0 20.0 60 10 3 10 5 10 Original_Datasets/ Original_Datasets/ Reduced_Matrices/ EigenVs/ FSMethods/ Transformed_Datasets/ Train_Test_Data/ ReducedMatrices_Train_Test_Data/ EigenVs_Train_Test_Data/ TransformedDatasets_Train_Test_Data/ 8 0.2 Plots/ 10 Raw_Datasets/

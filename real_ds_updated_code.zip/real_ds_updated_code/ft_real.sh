#! /bin/bash

generateData(){
	./transform 'Leukemia_Dataset/leukemia_train' 'Leukemia_ReducedMatrices_Train_Test_Data/' 'Leukemia_Dataset/'
	python3 eigenGen.py 'Leukemia_ReducedMatrices_Train_Test_Data/leukemia_train' 'Leukemia_EigenVs_Train_Test_Data/'
	D=$(./calcNormDist 'Leukemia_Dataset/leukemia_train' 'Leukemia_Dataset/' '' '' '')
	echo ${D}
	echo -n "`python3 solve_linear_equations.py 'Leukemia_Dataset/leukemia_' 'Leukemia_ReducedMatrices_Train_Test_Data/leukemia_train' 'Leukemia_EigenVs_Train_Test_Data/leukemia_train_vectors' $1 ${D} 'Leukemia_Transformed_Train_Test_Data/'`"
	echo -n "`python3 classification_unittest.py 'Leukemia_Dataset/leukemia' $1 'Leukemia_Transformed_Train_Test_Data/leukemia'`" >> leukemia_classification_score.csv
}

generateData 10

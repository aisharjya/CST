import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d
import sys
from sklearn.datasets import make_classification
from sklearn.datasets import make_blobs
from sklearn.datasets import make_gaussian_quantiles
import pandas as pd

# Generate some data
samples = int(sys.argv[1])
n_centers = int(sys.argv[2])
std_cluster = float(sys.argv[3])
features = int(sys.argv[4])
sampleNo = int(sys.argv[5])
folderLoc = str(sys.argv[6])
outPlotLoc = str(sys.argv[7])
labelLoc = str(sys.argv[8])
informative = int(sys.argv[9])
plt.figure(figsize=(8, 8))
X1, Y1 = make_classification(n_samples=samples, n_features=features, n_redundant=0, n_informative=10,
                             n_classes=n_centers, n_clusters_per_class=1, class_sep=std_cluster, flip_y=0, weights=[0.5,0.5])
df = pd.DataFrame(data=X1)
df.to_csv(folderLoc+str(samples)+'_'+str(n_centers)+'_'+str(std_cluster)+'_'+str(features)+'_'+str(sampleNo), sep=' ', index=False, header=False)
with open(labelLoc+str(samples)+'_'+str(n_centers)+'_'+str(std_cluster)+'_'+str(features)+'_'+str(sampleNo)+'_class', "w") as myfile:
	myfile.write(" ".join(map(str, Y1.tolist())))

#fig = plt.figure()
ax = plt.axes(projection='3d')
xdata = X1[:, 0]
ydata = X1[:, 1]
zdata = X1[:, 2]
ax.scatter3D(xdata, ydata, zdata, c=Y1)
#plt.show()
"""
plt.scatter(X1[:, 0], X1[:, 1], marker='o', c=Y1, s=30, edgecolor=Y1)
plt.grid()
plt.savefig(outPlotLoc+'classif_'+str(std_cluster)+'_'+str(sampleNo)+'_0_vs_1.pdf')
"""

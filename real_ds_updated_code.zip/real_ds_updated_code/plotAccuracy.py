import pandas as pd
import csv
import matplotlib.pyplot as plt
import sys

def main():
	fileName = str(sys.argv[1])
	c = str(sys.argv[2])
	classif = str(sys.argv[3])
	print(classif)
	data = pd.read_csv(fileName, sep=",", header=None)

	if classif == "kNN":
		plot_knn(data, c)

	if classif == "SVM":
		plot_svm(data, c)

	if classif == "GNB":
		plot_gnb(data, c)		


################################ kNN 

def plot_knn(data, c):
	plt.plot(data[4], data[6], 'ko-', label='PCA_kNN', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[18], 'ms-', label='MI_kNN', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[30], 'bo-', label='FT_kNN', linewidth=1.8, markersize=6)

	plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Informative_Features = 10, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()
	plt.savefig('BAC_60_10i_kNN_'+str(c)+'.pdf')

################################ SVM

def plot_svm(data, c):
	plt.plot(data[4], data[10], 'ko-', label='PCA_SVM', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[22], 'ms-', label='MI_SVM', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[34], 'bo-', label='FT_SVM', linewidth=1.8, markersize=6)

	#plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Informative_Features = 10, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()

	plt.savefig('BAC_60_10i_SVM_'+str(c)+'.pdf')

################################ GNB

def plot_gnb(data, c):
	plt.plot(data[4], data[14], 'ko-', label='PCA_GNB', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[26], 'ms-', label='MI_GNB', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[38], 'bo-', label='FT_GNB', linewidth=1.8, markersize=6)

	plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Informative_Features = 10, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()

	plt.savefig('BAC_60_10i_GNB_'+str(c)+'.pdf')

main()

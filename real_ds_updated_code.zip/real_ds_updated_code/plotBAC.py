import pandas as pd
import csv
import matplotlib.pyplot as plt
import sys

def main():
	fileName = str(sys.argv[1])
	c = str(sys.argv[2])
	classif = str(sys.argv[3])
	print(classif)
	data = pd.read_csv(fileName, sep=",", header=None)

	if classif == "kNN":
		plot_knn(data, c)

	if classif == "SVM":
		plot_svm(data, c)

	if classif == "GNB":
		plot_gnb(data, c)		


################################ kNN 

def plot_knn(data, c):
	plt.plot(data[4], data[6], 'ko-', label='PCA_kNN', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[9], 'ms-', label='MI_kNN', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[12], 'bo-', label='FT_kNN', linewidth=1.8, markersize=6)

	#plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Std. dev = 20.0, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()
	plt.savefig('BAC_60_sd20_kNN_'+str(c)+'.pdf')

################################ SVM

def plot_svm(data, c):
	plt.plot(data[4], data[7], 'ko-', label='PCA_SVM', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[10], 'ms-', label='MI_SVM', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[13], 'bo-', label='FT_SVM', linewidth=1.8, markersize=6)

	#plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Std. dev = 20.0, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()

	plt.savefig('BAC_60_sd20_SVM_'+str(c)+'.pdf')

################################ GNB

def plot_gnb(data, c):
	plt.plot(data[4], data[8], 'ko-', label='PCA_GNB', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[11], 'ms-', label='MI_GNB', linewidth=1.8, markersize=6)
	plt.plot(data[4], data[14], 'bo-', label='FT_GNB', linewidth=1.8, markersize=6)

	#plt.ylim(0.4, 1.1)
	plt.ylabel('BAC', fontsize=14)
	plt.xlabel('#Features', fontsize=14)
	plt.xticks(fontsize=14)
	plt.yticks(fontsize=14)
	label = '#Features = 60, #Std. dev = 20.0, c = ' + str(c)
	plt.title(label, fontdict=None, loc='center', fontsize=14)
	plt.legend(loc='upper left')
	plt.grid()

	plt.savefig('BAC_60_sd20_GNB_'+str(c)+'.pdf')

main()

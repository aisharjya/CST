from scipy.stats import special_ortho_group
import scipy.linalg
import numpy as np
import sys
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d

fileName = str(sys.argv[1])
data = pd.read_csv(fileName, sep=" ", header=None)
outputFilePath = str(sys.argv[2]) + fileName[fileName.rfind("/")+1:]
#print(outputFilePath)
X = special_ortho_group.rvs(int(sys.argv[3]))
#print(X)

## Test whether X is orthogonal: Multiply to its transpose -> Identity matrix 
#print(np.dot(X, X.T))

## Determinant of orthogonal matrix -> +/-1
#print(scipy.linalg.det(X))

rotated_data = np.dot(data, X)
df = pd.DataFrame(data=rotated_data)
#np.savetxt(outputFilePath, rotated_data, delimiter=' ')
df.to_csv(outputFilePath, sep=' ', index=False, header=False)


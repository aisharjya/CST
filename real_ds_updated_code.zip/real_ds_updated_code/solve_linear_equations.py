import numpy as np
import pandas as pd
import pprint
import scipy
import scipy.linalg
import sys
import math

epsilon=1*10**(-14)
#c = 0.0000000001
c = 0.5

def main():
	orig_data_path_train = str(sys.argv[1])+'_train'
	orig_data_path_test = str(sys.argv[1])+'_test'
	path1 = str(sys.argv[2])		## "output/test1_redMat" -> 
	path2 = str(sys.argv[3])		## "output/test1_eigenVec" -> 
	dim = int(sys.argv[4])			## dimensions
	D = float(sys.argv[5])
	output_path = str(sys.argv[6])
	fileName_train = orig_data_path_train[orig_data_path_train.rfind('/')+1:len(orig_data_path_train)]
	fileName_test = orig_data_path_test[orig_data_path_test.rfind('/')+1:len(orig_data_path_test)]
	orig_data_train = np.loadtxt(orig_data_path_train, dtype='double', delimiter=" ")			## Load Original data matrix train
	orig_data_test = np.loadtxt(orig_data_path_test, dtype='double', delimiter=" ")				## Load Original data matrix test
	A = np.loadtxt(path1, dtype='double', delimiter=" ")							## Load Reduced Matrix
	basis = pd.read_csv(path2, delimiter=" ", header=None)							## Load eigen vectors
	basis = basis[basis.columns[0]]										## Keep the first eigen vector
	basis = basis.to_frame()										## Convert Series to Dataframe
	P, L, U = scipy.linalg.lu(A)										## LU Decomposition of A matrix

	while(len(basis.columns) < dim):
		basis_sum = basis.sum(axis = 1)									## Calculate row-wise sum for basis
		basis_sum = basis_sum.to_frame()
		b = basis_sum.iloc[:, 0] * c * D								## Calculate c.D.b
		#b = b.values.reshape((4,1))
		#print(b)

		### PA = LU => LUx = Pb => Ly = Pb => Ux = y ###
		## Calculate Ly = Pb ##
		b1 = np.dot(P.T, b)
		y = scipy.linalg.solve_triangular(L, b1, lower=True)
		#print(y)

		## Calculate Ux = y ##
		x = scipy.linalg.solve_triangular(U, y, lower=False)
		#print(x)

		basis[len(basis.columns)] = x
		
		'''
		## Quality check		
		B = np.dot(A, x)
		for i in range(len(b)):
			print(abs(B[i] - b[i])<epsilon)
			print(math.isclose(B[i], b[i], abs_tol=epsilon))
			print()
		'''
	print(basis)
	transformed_dataset_train = np.dot(orig_data_train, basis)
	transformed_dataset_test = np.dot(orig_data_test, basis)
	np.savetxt(output_path+fileName_train, transformed_dataset_train, delimiter=' ')
	np.savetxt(output_path+fileName_test, transformed_dataset_test, delimiter=' ')

	return 0	

main()

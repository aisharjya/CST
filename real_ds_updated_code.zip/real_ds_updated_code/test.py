import pandas as pd
import pprint
import scipy
import scipy.linalg
import numpy as np

A = np.array([[1,3,4],[2,1,3],[4,1,2]])
print(A)
print()
P, L, U = scipy.linalg.lu(A)
print(np.dot(P.T, A))
print()
print(np.dot(L, U))

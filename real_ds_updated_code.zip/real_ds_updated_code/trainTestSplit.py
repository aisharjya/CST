import pandas
import numpy as np
import sys
from sklearn.model_selection import train_test_split

url1 = str(sys.argv[1])
url2 = url1 + "_class"
X = pandas.read_csv(url1, header=None, sep=' ')
Y = pandas.read_csv(url2, header=None, sep=' ')
Y = np.ravel(Y, order='C')
fileName = url1[url1.rfind('/')+1:len(url1)]
print(fileName)
trainData_testData_path = str(sys.argv[2])
kfold = int(sys.argv[3])
testSize = float(sys.argv[4])

for x in range(0, kfold):
	X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=testSize, random_state=x)

	df_train = pandas.DataFrame(data=X_train)
	df_train.to_csv(trainData_testData_path+str(fileName)+'_'+str(x+1)+'_train', sep=' ', index=False, header=False)

	df_test = pandas.DataFrame(data=X_test)
	df_test.to_csv(trainData_testData_path+str(fileName)+'_'+str(x+1)+'_test', sep=' ', index=False, header=False)

	with open(trainData_testData_path+str(fileName)+'_'+str(x+1)+'_train_class', "w") as y_trainFile:
		y_trainFile.write(" ".join(map(str, y_train.tolist())))

	with open(trainData_testData_path+str(fileName)+'_'+str(x+1)+'_test_class', "w") as y_testFile:
		y_testFile.write(" ".join(map(str, y_test.tolist())))
